/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividade;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Publications {
    private String title;
    private String conference_name;
    private int year;
    java.util.ArrayList<Project> associated = new java.util.ArrayList<>();
    java.util.ArrayList<Collaborator> members = new java.util.ArrayList<>();
    Scanner scanner = new Scanner(System.in);

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getConference_name() {
        return conference_name;
    }

    public void setConference_name(String conference_name) {
        this.conference_name = conference_name;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    
    public void CreatePublication()
    {
        System.out.print("Digite o título da publicação: ");
        String tt = scanner.nextLine();
        setTitle(tt);
        System.out.print("Digite o nome da conferência onde foi publicada: ");
        String name_conf = scanner.nextLine();
        setConference_name(name_conf);
        System.out.print("Digite o ano de publicação: ");
        int year_publi = scanner.nextInt();
        setYear(year_publi);   
    }
}
