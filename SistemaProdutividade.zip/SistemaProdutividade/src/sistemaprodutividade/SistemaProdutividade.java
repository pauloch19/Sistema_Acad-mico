package sistemaprodutividade;
import java.util.Scanner;

/**
 *
 * @author paulc
 */
public class SistemaProdutividade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        Sys system = new Sys();
        int option;
        System.out.println("Bem-Vindo ao Sistema de Gestão de Produtividade Acadêmica.");
        System.out.println("1.Alocar Colaboradores para o Laboratório\n2.Para criar projeto\n3.Editar Informações de um projeto\n4.Alocar Colaborador a um projeto");
        System.out.println("5.Iniciar Projeto\n6.Finalizar Projeto\n7.Produções Acadêmicas\n8.Consulta por colaborador\n9.Consulta por projeto\n10.Consulta de dados do laboratório\n11.Sair");
        System.out.print("Escolha uma opção: ");
        option = scanner.nextInt();
        scanner.nextLine();
        while(option!=11)
        {
            if(option==1)
            {
                System.out.println("Você entrou na opção para adicionar colaboradores ao laboratório.");
                Collaborator collaborator = new Collaborator();
                collaborator.CreateProfile();
                system.collaborators.add(collaborator);
                System.out.println("###############################################################################################################");
                System.out.println("O Colaborador "+collaborator.getName()+" foi associado ao laboratório.");
                System.out.println("###############################################################################################################");
            }
            if(option==2)
            {
                System.out.println("Você entrou na opção criar projeto.");
                Project project = new Project();
                project.PutTitle();
                system.projects.add(project);
                System.out.println("###############################################################################################################");
                System.out.println("O projeto "+project.getTitle()+" foi adicionado ao sistem do laboratório.");
                System.out.println("O Status do projeto é Em andamento, permanecerá assim até que todas as informações sejam inseridas.");
                System.out.println("Para inserir o restante das informações escolha a terceira opção.");
                System.out.println("###############################################################################################################");
            }
            if(option==3)
            {
                System.out.println("Você entrou na opção editar projeto.");
                System.out.println("Qual o título do projeto que você deseja editar? ");
                System.out.print("Digite o título aqui: ");
                String title = scanner.nextLine();
                Project auxiliar = system.SearchProjects(title);
                if(auxiliar==null)
                {
                    System.out.println("Projeto não se encontra no banco de dados do laboratório!");
                }
                else
                {
                    System.out.println("Projeto Encontrado, vamos prosseguir!");
                    if(auxiliar.getState().equals("Em Elaboração"))
                    {
                        auxiliar.InsertInformations();
                    }
                    else
                    {
                        System.out.println("As informações do projeto não podem mais ser alteradas.");
                    }
                }
            }
            if(option==4)
            {
                System.out.println("Você entrou na opção alocar colaborador a um projeto.");
                System.out.println("Qual o título do projeto que você deseja alocar membros?");
                System.out.print("Digite o título aqui: ");
                String title = scanner.nextLine();
                Project auxiliar = system.SearchProjects(title);
                if(auxiliar==null)
                {
                    System.out.println("Projeto não se encontra no banco de dados do laboratório!");
                }
                else
                {
                    System.out.println("Projeto Encontrado, vamos prosseguir!");
                    if(auxiliar.getState().equals("Em Elaboração"))
                    {
                        System.out.print("Digite o nome do Colaborador: ");
                        String name = scanner.nextLine();
                        Collaborator member = system.SearchCollaborator(name);
                        if(member==null)
                        {
                            System.out.println("Colaborador não foi encontrado no sistema.");
                        }
                        else
                        {
                            System.out.println("Colaborador encontrado!");
                            int count = member.VerifyProjectStates();
                            if(count>=2)
                            {
                                System.out.println("O Colaborador não pode participar do projeto pois ele está participando de dois projetos que estão em andamento.");
                            }
                            else
                            {
                                auxiliar.members.add(member);
                                member.projects_collaborator.add(auxiliar);
                            }
                        } 
                    }
                    else
                    {
                        System.out.println("O Projeto não está mais em fase de elaboração.");
                    }
                }
            }
            if(option==5)
            {
                System.out.println("Você entrou na opção para iniciar um projeto.");
                System.out.println("Qual projeto você deseja iniciar?");
                System.out.print("Digite aqui: ");
                String title = scanner.nextLine();
                Project auxiliar = system.SearchProjects(title);
                if(auxiliar==null)
                {
                    System.out.println("Projeto não encontrado no sistema.");
                }
                else
                {
                    System.out.println("Projeto encontrado!");
                    int count = auxiliar.SearchProfessors();
                    if(count==0)
                    {
                        System.out.println("O projeto não pode ser iniciado pois não há nenhum professor como colaborador.");
                    }
                    else
                    {
                        if(auxiliar.getState().equals("Em Elaboração") && auxiliar.getChecker()==1)
                        {
                            auxiliar.setState("Em Andamento");
                            auxiliar.setChecker(2);
                            System.out.println("Projeto iniciado com sucesso!");
                        }
                        else
                        {
                            System.out.println("Projeto não pode ser iniciado pois seus status não é Em Elaboração ou ele não possui todas as informações.");
                        }
                        
                    }
                }
            }
            if(option==6)
            {
                System.out.println("Você entrou na opção finalizar projeto.");
                System.out.print("Digite o título do projeto: ");
                String title = scanner.nextLine();
                Project auxiliar = system.SearchProjects(title);
                if(auxiliar==null)
                {
                    System.out.println("Projeto não encontrado.");
                }
                else
                {
                    System.out.println("Projeto encontrado!");
                    if(auxiliar.getState().equals("Em Andamento"))
                    {
                        if(auxiliar.publications.size()>0)
                        {
                            auxiliar.setState("Concluido");
                            auxiliar.setChecker(3);
                            System.out.println("Projeto concluido!");
                        }
                        else
                        {
                            System.out.println("Não há nenhuma publicação associada a esse projeto.");
                        }
                    }
                    else
                    {
                        System.out.println("O projeto não pode ser concluido por causa de seu status.");
                    }
                }
            }
            if(option==7)
            {
                System.out.println("Você entrou na opção Produções Acadêmicas.");
                System.out.println("1.Criar Publicação\n2.Criar Orientação\n3.Associar Colaboradores\n4.Associar Projetos\n5.Sair");
                option = scanner.nextInt();
                scanner.nextLine();
                while(option!=5)
                {
                    if(option==1)
                    {
                        System.out.println("Você entrou na opção Criar Publicação.");
                        Publications publication = new Publications();
                        publication.CreatePublication();
                        system.sys_publications.add(publication);
                    }
                    if(option==2)
                    {
                       System.out.println("Você entrou na opção Criar Orientação.");
                       Orientations orientation = new Orientations();
                       System.out.print("Qual o nome do professor que vai orientar os colaboradores: ");
                       String name = scanner.nextLine();
                       Collaborator member = system.SearchCollaborator(name);
                        if(member==null)
                        {
                            System.out.println("Colaborador não foi encontrado no sistema.");
                        }
                        else
                        {
                            System.out.println("Colaborador encontrado!");
                            if(member.getType().equals("professor"))
                            {
                                orientation.setLeader(name);
                                system.orientations.add(orientation);
                                member.orientations.add(orientation);
                                System.out.println("Orientação criada com sucesso!");
                            }
                            else
                            {
                                System.out.println("O colaborador não é professor.");
                            } 
                        }
                    }
                    if(option==3)
                    {
                        System.out.println("Você entrou na opção Associar colaboradores.");
                        System.out.println("A produção é uma:\n1.publicação\n2.orientação");
                        System.out.print("Digite: ");
                        option = scanner.nextInt();
                        scanner.nextLine();
                        if(option==1)
                        {
                            System.out.print("Qual o nome da publicação: ");
                            String publi_title = scanner.nextLine();
                            Publications auxiliar_publi = system.SearchPubli(publi_title);
                            if(auxiliar_publi==null)
                            {
                                System.out.println("Publicação não encontrada.");
                            }
                            else
                            {
                                System.out.println("Publicação encontrada!");
                                System.out.print("Digite o nome do colaborador: ");
                                String name = scanner.nextLine();
                                Collaborator member = system.SearchCollaborator(name);
                                if(member==null)
                                {
                                    System.out.println("Colaborador naõ se encontra no sistema.");
                                }
                                else
                                {
                                    System.out.println("Colaborador encontrado!");
                                    int count = member.VerifyPublications(auxiliar_publi.getTitle());
                                    if(count==0)
                                    {
                                        member.publications.add(auxiliar_publi);
                                        auxiliar_publi.members.add(member);
                                        System.out.println("Associação realizada com sucesso!");
                                    }
                                    else
                                    {
                                        System.out.println("O Colaborador já está associado a essa publicação.");
                                    }
                                    
                                }
                            }
                        }
                        if(option==2)
                        {
                            System.out.print("Primeiro, Digite o nome do professor que vai orientar: ");
                            String name = scanner.nextLine();
                            Collaborator member = system.SearchCollaborator(name);
                            if(member==null)
                            {
                                System.out.println("Colaborador não encontrado.");
                            }
                            else
                            {
                                System.out.println("Colaborador encontrado!");
                                Orientations auxiliar_ori = member.orientations.get(0);
                                System.out.println("Orientação obtida com sucesso!");
                                System.out.print("Qual o nome do colaborador que será adicionado a orientação: ");
                                name = scanner.nextLine();
                                Collaborator member_col = system.SearchCollaborator(name);
                                if(member_col==null)
                                {
                                    System.out.println("Colaborador naõ se encontra no sistema.");
                                }
                                else
                                {
                                    System.out.println("Colaborador encontrado!");
                                    auxiliar_ori.members.add(member_col);
                                    member_col.orientations.add(auxiliar_ori);
                                }
                                
                            }
                            
                        }
                    }
                    if(option==4)
                    {
                        System.out.println("Você entrou na opção Associar projetos");
                        System.out.println("A produção é uma:\n1.publicação");
                        System.out.print("Digite: ");
                        option = scanner.nextInt();
                        scanner.nextLine();
                        if(option==1)
                        {
                            System.out.print("Qual o nome da publicação: ");
                            String publi_title = scanner.nextLine();
                            Publications auxiliar_publi = system.SearchPubli(publi_title);
                            if(auxiliar_publi==null)
                            {
                                System.out.println("Publicação não encontrada.");
                            }
                            else
                            {
                                System.out.print("Nome do projeto que será associado: ");
                                String title = scanner.nextLine();
                                Project auxiliar = system.SearchProjects(title);
                               if(auxiliar==null)
                               {
                                    System.out.println("Projeto não encontrado no sistema.");
                               }
                               else
                               {
                                   System.out.println("Projeto encontrado!");
                                   if(auxiliar.getState().equals("Em Andamento"))
                                   {
                                    auxiliar_publi.associated.add(auxiliar);
                                    auxiliar.publications.add(auxiliar_publi);
                                    System.out.println("O projeto e a publicação foram associados com sucesso!");
                                   }
                                   else
                                   {
                                       System.out.println("O status do projeto não é Em Andamento.");
                                   }
                               }     
                            }
                        }
                    } 
                    System.out.print("Escolha outra opção: ");
                    option = scanner.nextInt();
                    scanner.nextLine();
                }  
            }
            if(option==8)
            {
                System.out.println("Você entrou na opção consultar por colaborador.");
                System.out.print("Digite o nome do colaborador: ");
                String name = scanner.nextLine();
                Collaborator member = system.SearchCollaborator(name);
                if(member==null)
                {
                    System.out.println("Colaborador não encontrado.");
                }
                else
                { 
                    member.Sorting();   
                    System.out.println("Colaborador encontrado!");
                    System.out.println("Nome: "+member.getName());
                    System.out.println("E-mail: "+member.getEmail());
                    System.out.println("Projetos Em Elaboração: ");
                    member.ConsultingElaborationProjects();
                    System.out.println("Projetos Em Andamento: ");
                    member.ConsultingOngoingProjects();
                    System.out.println("Projetos Concluidos: ");
                    member.ConsultingFinishedProjects();
                    System.out.println("Produções Acadêmcias: ");
                    if(!member.getType().equals("professor"))
                    {
                         member.Academic();
                    }
                    else
                    {
                        member.Academic();
                        member.VerifyOrientations();
                    }
                }
            }
            if(option==9)
            {
                System.out.println("Você entrou na opção consultar por projeto.");
                System.out.print("Digite o nome do projeto: ");
                String title = scanner.nextLine();
                Project auxiliar = system.SearchProjects(title);
                if(auxiliar==null)
                {
                    System.out.println("Projeto não encontrado no sistema.");
                }
                else
                {
                    System.out.println("Projeto encontrado!");
                    system.ShowProjects(auxiliar);
                    System.out.println("Colaboradores: ");
                    auxiliar.ShowCollaborators();
                    System.out.println("Produções Acadêmicas: ");
                    auxiliar.ShowAcademics();
                }    
            }
            if(option==10)
            {
                System.out.println("Você entrou na opção consultar dados do projeto.");
                System.out.println("Número de colaboradores: "+system.collaborators.size());
                system.ShowAllProjects();
                
            }
            System.out.print("Escolha outra opção: ");
            option = scanner.nextInt();
            scanner.nextLine();
        }
    }
    
}
