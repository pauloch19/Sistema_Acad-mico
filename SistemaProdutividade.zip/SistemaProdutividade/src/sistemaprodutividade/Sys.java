/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividade;

/**
 *
 * @author paulc
 */
public class Sys {
    
    java.util.ArrayList<Project> projects = new java.util.ArrayList<>();
    java.util.ArrayList<Collaborator> collaborators = new java.util.ArrayList<>();
    java.util.ArrayList<Publications> sys_publications = new java.util.ArrayList<>();
    java.util.ArrayList<Orientations> orientations = new java.util.ArrayList<>();
    
    
    public Project SearchProjects(String title)
    {
        int i;
        Project project;
        Project found = null;
        for(i=0;i<projects.size();i++)
        {
           project = projects.get(i);
           if(project.getTitle().equals(title))
           {
               found = project;
           }
        }   
        return found;
    }
    
    public Collaborator SearchCollaborator(String name)
    {
        int i;
        Collaborator collaborator;
        Collaborator found = null;
        for(i=0;i<collaborators.size();i++)
        {
            collaborator = collaborators.get(i);
            if(collaborator.getName().equals(name))
            {
                found = collaborator;
            }
        }
        
        return found;
    }
    
    public void ShowProjects(Project project)
    {
           System.out.println("Título: "+project.getTitle());
           System.out.println(project.getYear_start()+"-"+project.getYear_end());
           System.out.println("Status: "+project.getState());
           System.out.println("Descrição: "+project.getDescription());
           System.out.println("Objetivo: "+project.getGoal());
           System.out.println("Agência: "+project.getAgency());
           System.out.println("Valor Financiado: "+project.getFinanced_amount());
    }
    
    public Publications SearchPubli(String title)
    {
        int i;
        Publications publication;
        Publications found = null;
        for(i=0;i<sys_publications.size();i++)
        {
           publication = sys_publications.get(i);
           if(publication.getTitle().equals(title))
           {
               found = publication;
           }
        }   
        return found;
    }
    
    public void ShowAllProjects()
    {
        int i;
        int c1=0, c2=0, c3=0;
        Project project;
        for(i=0;i<projects.size();i++)
        {
            project = projects.get(i);
            if(project.getState().equals("Em Andamento"))
            {
                c1++;
            }
            if(project.getState().equals("Em Elaboração"))
            {
                c2++;
            }
            if(project.getState().equals("Concluido"))
            {
                c3++;
            }
        }
        System.out.println("Número de projetos em elaboração: "+c2);
        System.out.println("Número de projetos em andamento: "+c1);
        System.out.println("Núemro de projetos concluídos: "+c3);
        System.out.println("Número total de projetos: "+projects.size());
        System.out.println("Número de Publicações: "+sys_publications.size());
        System.out.println("Número de Orientações: "+orientations.size());
    }
    
}
