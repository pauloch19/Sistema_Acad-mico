/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividade;

/**
 *
 * @author paulc
 */
public class Orientations {
    private String leader;
    java.util.ArrayList<Collaborator> members = new java.util.ArrayList<>();

    public String getLeader() {
        return leader;
    }

    public void setLeader(String leader) {
        this.leader = leader;
    }
    
    
    
    
    
    
    
    
    
    
}
