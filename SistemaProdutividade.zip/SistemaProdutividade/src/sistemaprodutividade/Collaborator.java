/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividade;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Collaborator {
    private String name;
    private String type;
    private String email;
    java.util.ArrayList<Publications> publications = new java.util.ArrayList<>();
    java.util.ArrayList<Orientations> orientations = new java.util.ArrayList<>();
    java.util.ArrayList<Project> projects_collaborator = new java.util.ArrayList<>();
    Scanner scanner = new Scanner(System.in);
    
      public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    public void CreateProfile()
    {
        System.out.print("Qual o nome do colaborador: ");
        String collaborator_name = scanner.nextLine();
        setName(collaborator_name);
        System.out.print("Qual o e-mail: ");
        String collaborator_email = scanner.nextLine();
        setEmail(collaborator_email);
        System.out.println("O coladorador faz parte de qual categoria: ");
        System.out.println("aluno de graduação.\naluno de mestrado.\naluno de doutorado.\nprofessor.\npesquisador.");
        System.out.print("Digite aqui: ");
        String collaborator_type = scanner.nextLine();
        setType(collaborator_type);
    }
    
    public int VerifyProjectStates()
    {
        int i, count=0;
        Project project;
        for(i=0;i<projects_collaborator.size();i++)
        {
            project = projects_collaborator.get(i);
            if(project.getState().equals("Em Andamento"))
            {
                count++;
            }  
        }
        return count;
    }
    
    public int VerifyPublications(String name)
    {
        
        int i, count=0;
        Publications publication;
        for(i=0;i<publications.size();i++)
        {
            publication = publications.get(i);
            if(publication.getTitle().equals(name))
            {
                count=1;
                break;
            }
        }
       return count;
    }
    
   public void VerifyOrientations()
    {
        int i;
        Orientations orientation;
        for(i=0;i<orientations.size();i++)
        {
            orientation = orientations.get(i);
            System.out.println("Orientado pelo professor "+orientation.getLeader()+".");
        }
    }
    
    public void ConsultingElaborationProjects()
    {
        
      int i, j;
      Project project1;
      for(i=0;i<projects_collaborator.size();i++)
      {
          project1 = projects_collaborator.get(i);
          if(project1.getState().equals("Em Elaboração"))
          {
              System.out.println(project1.getTitle());
          }
      }
    }
    
    public void ConsultingFinishedProjects()
    {
        
      int i, j;
      Project project1;
      for(i=0;i<projects_collaborator.size();i++)
      {
          project1 = projects_collaborator.get(i);
          if(project1.getState().equals("Concluido"))
          {
              System.out.println(project1.getTitle());
          }
      }
    }
    
    public void ConsultingOngoingProjects()
    {
        int i;
        Project project1;
        for(i=0;i<projects_collaborator.size();i++)
        {
          project1 = projects_collaborator.get(i);
          if(project1.getState().equals("Em Andamento"))
          {
              System.out.println(project1.getTitle());
          }
        }
    }
    
    public void Sorting()
    {
      int i, j;
      int n = projects_collaborator.size();
      Project auxiliar;
      for(i=0;i<n;i++)
      {
          for(j=i+1;j<n;j++)
          {   
              if(projects_collaborator.get(j).getYear_end()>projects_collaborator.get(i).getYear_end())
              {
                  auxiliar = projects_collaborator.get(j);
                  projects_collaborator.set(j, projects_collaborator.get(i));
                  projects_collaborator.set(i, auxiliar);
              }
          }
         
         
      }
    }
    
    public void Academic()
    {
        int i;
        Publications publi;
        for(i=0;i<publications.size();i++)
        {
            publi = publications.get(i);
            System.out.println(publi);
        }
    }
}
