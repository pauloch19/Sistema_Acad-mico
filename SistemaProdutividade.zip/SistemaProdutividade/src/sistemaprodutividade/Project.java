/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividade;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Project {
    private String state;
    private String title;
    private String agency;
    private String goal;
    private String description;
    private int year_start;
    private int year_end;
    private int financed_amount;
    private int checker;
    java.util.ArrayList<Collaborator> members = new java.util.ArrayList<>();
    java.util.ArrayList<Publications> publications = new java.util.ArrayList<>();
    Scanner scanner = new Scanner(System.in);

    public int getChecker() {
        return checker;
    }

    public void setChecker(int checker) {
        this.checker = checker;
    }
    
    
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public int getYear_start() {
        return year_start;
    }

    public void setYear_start(int year_start) {
        this.year_start = year_start;
    }
    
    public int getYear_end() {
        return year_end;
    }

    public void setYear_end(int year_end) {
        this.year_end = year_end;
    }

    public String getAgency() {
        return agency;
    }

    public void setAgency(String agency) {
        this.agency = agency;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getFinanced_amount() {
        return financed_amount;
    }

    public void setFinanced_amount(int financed_amount) {
        this.financed_amount = financed_amount;
    }
    
    
    
    public void PutTitle()
    {
        System.out.print("Digite o título do projeto: ");
        String title_project = scanner.nextLine();
        setTitle(title_project);
        setState("Em Elaboração");
        setChecker(0);
    }
      
    public void InsertInformations()
    {
        System.out.print("Digite o ano de inicio do projeto: ");
        int start = scanner.nextInt();
        setYear_start(start);
        System.out.print("Digite o ano de término do projeto: ");
        int end = scanner.nextInt();
        scanner.nextLine();
        setYear_end(end);
        System.out.print("Por favor, informe a agência financiadora do projeto: ");
        String funding_agency = scanner.nextLine();
        setAgency(funding_agency);
        System.out.print("Qual o valor financiado para o projeto: ");
        int value = scanner.nextInt();
        setFinanced_amount(value);
        scanner.nextLine();
        System.out.print("Qual o objetivo do projeto: ");
        String objective = scanner.nextLine();
        setGoal(objective);
        System.out.print("Qual a descrição do projeto: ");
        String describe = scanner.nextLine();
        setDescription(describe);
        setChecker(1);
    }
    
    public int SearchProfessors()
    {
        int i, count=0;
        Collaborator member;
        for(i=0;i<members.size();i++)
        {
            member = members.get(i);
            if(member.getType().equals("professor"))
            {
                count++;
            }
        }
        return count;
    }

    
    public void ShowCollaborators()
    {
        int i;
        Collaborator member;
        for(i=0;i<members.size();i++)
        {
            member = members.get(i);
            System.out.println(member.getName());
       }
    }
    
    public void ShowAcademics()
    {
        int i;
        Publications publi;
        for(i=0;i<publications.size();i++)
        {
           publi = publications.get(i);
           System.out.println(publi.getTitle());
        }
    }
    
    
    
}
